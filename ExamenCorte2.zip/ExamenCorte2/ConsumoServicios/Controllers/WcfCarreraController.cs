﻿using ConsumoServicios.WCFServiceReference;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ConsumoServicios.Controllers
{
    public class WcfCarreraController : Controller
    {
        Service1Client service = new Service1Client();

        // GET: WcfCarrera
        public ActionResult Index()
        {
            var lista = service.ListaCarreraGetAllResult();
            return View(lista);
        }
    }
}