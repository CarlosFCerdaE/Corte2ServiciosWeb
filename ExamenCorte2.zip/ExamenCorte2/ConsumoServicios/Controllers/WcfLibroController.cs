﻿using ConsumoServicios.WCFServiceReference;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ConsumoServicios.Controllers
{
    public class WcfLibroController : Controller
    {
        // GET: WcfLibro
        Service1Client service = new Service1Client();
        public ActionResult Index()
        {
            var lista = service.ListaLibroGetAllResult();
            return View(lista);
        }
    }
}