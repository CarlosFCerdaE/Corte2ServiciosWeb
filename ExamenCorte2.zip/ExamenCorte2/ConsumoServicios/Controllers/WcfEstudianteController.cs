﻿using ConsumoServicios.WCFServiceReference;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Services.Description;

namespace ConsumoServicios.Controllers
{
    public class WcfEstudianteController : Controller
    {
        // GET: WcfEstudiante

        Service1Client service = new Service1Client();
        public ActionResult Index()
        {
            var lista = service.ListaEstudianteGetAllResult();
            return View(lista);
        }
    }
}