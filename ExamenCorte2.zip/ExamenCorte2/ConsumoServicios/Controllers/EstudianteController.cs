﻿using ConsumoServicios.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace ConsumoServicios.Controllers
{
    public class EstudianteController : Controller
    {
        // GET: Estudiante
        public async Task<ActionResult> Index()
        {
            var client = new HttpClient();
            var url = ConfigurationManager.AppSettings["apiurl"];
            var endpoint = "estudiante";
            var Json = await client.GetStringAsync(url + endpoint);
            var result = JsonConvert.DeserializeObject<List<Estudiante>>(Json);

            return View(result);
        }
    }
}