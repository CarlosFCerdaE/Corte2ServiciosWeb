﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Xml.Linq;

namespace ConsumoServicios.Models
{
    public class Estudiante
    {
        [Display(Name = "CIF")]
        public string cif { get; set; }
        [Display(Name = "Nombre")]
        public string nombre { get; set; }

        [Display(Name = "Apellido")]
        public string apellido { get; set; }

        [Display(Name = "Carrera")]
        public string carrera { get; set; }
    }
}