﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Xml.Linq;

namespace ConsumoServicios.Models
{
    public class Carrera
    {
        [Display(Name = "Id Carrera")]
        public string carreraId { get; set; }
        [Display(Name = "Nombre")]
        public string nombre { get; set; }

        [Display(Name = "Facultad")]
        public string facultad { get; set; }
    }
}