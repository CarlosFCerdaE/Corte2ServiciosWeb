﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Xml.Linq;

namespace ConsumoServicios.Models
{
    public class Libro
    {
        [Display(Name = "ISBN")]
        public string isbn { get; set; }
        [Display(Name = "Nombre")]
        public string nombre { get; set; }

        [Display(Name = "Editorial")]
        public string editorial { get; set; }

        [Display(Name = "Autor")]
        public string autor { get; set; }
    }
}