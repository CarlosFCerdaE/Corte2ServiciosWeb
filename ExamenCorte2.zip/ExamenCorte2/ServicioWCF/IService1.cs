﻿using ServicioWCF.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace ServicioWCF
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "IService1" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface IService1
    {
        //Carrera
        [OperationContract]
        List<GetAllLCarrera_Result> ListaCarreraGetAllResult();
        [OperationContract]
        SaveCarrera_Result SaveCarrera(string id, string nombre, string facultad);
        [OperationContract]
        DeleteCarrera_Result DeleteCarrera(string id);

        //Estudiante

        [OperationContract]
        List<GetAllEstudiante_Result> ListaEstudianteGetAllResult();
        [OperationContract]
        SaveEstudiante_Result SaveEstudiante(string cif, string nombre, string apellido, string carrera);
        [OperationContract]
        DeleteEstudiante_Result DeleteEstudiante(string cif);

        //Libro

        [OperationContract]
        List<GetAllLibro_Result> ListaLibroGetAllResult();
        [OperationContract]
        SaveLibro_Result SaveLibro(string isbn, string nombre, string editorial, string autor);
        [OperationContract]
        DeleteLibro_Result DeleteLibro(string isbn);



    }
}
