﻿using ServicioWCF.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace ServicioWCF
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "Service1" en el código, en svc y en el archivo de configuración.
    // NOTE: para iniciar el Cliente de prueba WCF para probar este servicio, seleccione Service1.svc o Service1.svc.cs en el Explorador de soluciones e inicie la depuración.
    public class Service1 : IService1
    {

        BDPRUEBASEntities2 bd = new BDPRUEBASEntities2();
        //Carrera
        public List<GetAllLCarrera_Result> ListaCarreraGetAllResult()
        {
            return bd.GetAllLCarrera().ToList();
        }

        public SaveCarrera_Result SaveCarrera(string id, string nombre, string facultad)
        {
            return bd.SaveCarrera(id, nombre, facultad).FirstOrDefault();
        }

        public DeleteCarrera_Result DeleteCarrera(string id)
        {
            return bd.DeleteCarrera(id).FirstOrDefault();
        }

        //Estudiante

        public List<GetAllEstudiante_Result> ListaEstudianteGetAllResult()
        {
            return bd.GetAllEstudiante().ToList();
        }

        public SaveEstudiante_Result SaveEstudiante(string cif, string nombre, string apellido, string carrera)
        {
            return bd.SaveEstudiante(cif, nombre, apellido, carrera).FirstOrDefault();
        }

        public DeleteEstudiante_Result DeleteEstudiante(string cif)
        {
            return bd.DeleteEstudiante(cif).FirstOrDefault();
        }

        //Libro

        public List<GetAllLibro_Result> ListaLibroGetAllResult()
        {
            return bd.GetAllLibro().ToList();
        }

        public SaveLibro_Result SaveLibro(string isbn, string nombre, string editorial, string autor)
        {
            return bd.SaveLibro(isbn, nombre, editorial, autor).FirstOrDefault();
        }

        public DeleteLibro_Result DeleteLibro(string isbn)
        {
            return bd.DeleteLibro(isbn).FirstOrDefault();
        }

    }
}
